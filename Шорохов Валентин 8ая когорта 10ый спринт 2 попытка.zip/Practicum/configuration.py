URL_SERVICE = 'https://541d1708-2aa4-4039-91bd-cb31c57ec93f.serverhub.praktikum-services.ru'
DOC_PATH = '/docs/'
LOG_MAIN_PATH = '/api/logs/main'
USERS_TABLE_PATH = "/api/db/resources/user_model.csv"
CREATE_USER_PATH = "/api/v1/users/"
PRODUCTS_KITS_PATH = "/api/v1/products/kits/"
CREATE_NEW_KIT_PATH = "/api/v1/kits"
