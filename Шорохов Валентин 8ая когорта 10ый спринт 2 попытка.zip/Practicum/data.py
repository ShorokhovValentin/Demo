headers = {
    "Content-Type": "application/json"
}

user_body = {
    "firstName": "Анатолий",
    "phone": "+79995553322",
    "address": "г. Москва, ул. Пушкина, д. 10"
}

product_ids = {
    "ids": [1, 2, 3]
}

headers_kit = {
    "Content-Type": "application/json",
    "Authorization": "Bearer jknnFApafP4awfAIFfafam2fma"
}

kit_body = {
    "name": "Мой набор"
}

authToken = "6896bd48-f0d1-4a51-a9b4-0d5f29c0b171"
